// utils/exchangeMap.js
export const exchangeToCountry = {
    "NasdaqGS": "États-Unis",
    "Nasdaq": "États-Unis",
    "NASDAQ": "États-Unis",
    "NYSE": "États-Unis",
    "Euronext Paris": "France",
    "EPA": "France",
    "Paris": "France",
    "XETRA": "Allemagne",
    "Frankfurt": "Allemagne",
    "London": "Royaume-Uni",
    "Tokyo": "Japon",
    "Toronto": "Canada",
    "Hong Kong": "Chine",
    "Milan": "Italie"
  };
  